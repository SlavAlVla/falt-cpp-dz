#include <std_lib_facilities.h>
#include "Token.h"

void Token_stream::putback(Token t)
{
  if (full)
    error("putback() into a full buffer");

  buffer = t;
  full = true;
}

Token Token_stream::get()
{
  if (full)
  {
    full = false;
    return buffer;
  }
}

void Token_stream::ignore(char c)
{
  if (full && c == buffer.kind)
  {
    full = false;
    return;
  }
  full = false;

  for (char ch; cin >> ch;)
  {
    if (ch == c)
      return;
  }
}