#include "UIGroupManager/UIGroupManager.h"
#include <FL/Fl_Window.H>

class MainWindow : public Fl_Window {
    UIGroupManager* manager;

  public:
    MainWindow () : Fl_Window{400, 300, "Fractal"} {
        manager = new MainGroupManager{};
        this->end();
        this->show();
    }
};