#include "UIGroupManager.h"
#include "UIGroup/UIGroup.h"
#include <iostream>

void UIGroupManager::switch_group (const std::string& gr) {
    std::cout << gr << std::endl;
    if (curr_group)
        curr_group->hide();

    if (groups.count(gr)) {
        curr_group = groups[gr];
        curr_group->show();
    }
}

MainGroupManager::MainGroupManager () {
    groups["menu"] = new MenuGroup(400, 300, this);
    groups["fractal"] = new FractalGroup(400, 300, this);
    for (auto& [name, gr] : groups) {
        gr->hide();
    }
    curr_group = groups["fractal"];
    curr_group->show();
}