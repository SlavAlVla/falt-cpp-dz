#pragma once
#include <map>

class UIGroup;

class UIGroupManager {
  protected:
    std::map<std::string, UIGroup*> groups;
    UIGroup* curr_group = nullptr;

  public:
    void switch_group (const std::string& gr);

    virtual ~UIGroupManager () = default;
};

class MainGroupManager : public UIGroupManager {
  public:
    MainGroupManager ();
};