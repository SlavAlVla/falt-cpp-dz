#pragma once
#include "UIGroupManager/UIGroupManager.h"
#include <FL/Fl_Button.H>
#include <FL/Fl_Group.H>

class UIGroup : public Fl_Group {
  protected:
    UIGroupManager* manager_;

  public:
    UIGroup (int w, int h, UIGroupManager* manager, int x = 0, int y = 0);

    virtual ~UIGroup () = default;
};

class MenuGroup : public UIGroup {
  private:
    Fl_Button* to_fractal_btn;

    static void to_fractal_btn_callback (Fl_Widget* wid, void* data);

  public:
    MenuGroup (int w, int h, UIGroupManager* manager, int x = 0, int y = 0);
};

class FractalGroup : public UIGroup {
  private:
    Fl_Button* to_menu_btn;

    static void to_menu_btn_callback (Fl_Widget* wid, void* data);

  public:
    FractalGroup (int w, int h, UIGroupManager* manager, int x = 0,
                  int y = 0);
};