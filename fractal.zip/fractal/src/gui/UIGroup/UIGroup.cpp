#include "UIGroup.h"

UIGroup::UIGroup (int w, int h, UIGroupManager* manager, int x, int y)
    : Fl_Group{x, y, w, h} {
    manager_ = manager;
}

void MenuGroup::to_fractal_btn_callback (Fl_Widget* wid, void* data) {
    UIGroupManager* manager = reinterpret_cast<UIGroupManager*>(data);
    manager->switch_group("fractal");
}

MenuGroup::MenuGroup (int w, int h, UIGroupManager* manager, int x, int y)
    : UIGroup(w, h, manager, x, y) {
    {
        to_fractal_btn = new Fl_Button{100, 100, 100, 20, "To Fractal"};
        to_fractal_btn->callback(MenuGroup::to_fractal_btn_callback,
                                 &manager_);
    }
    this->end();
}

void FractalGroup::to_menu_btn_callback (Fl_Widget* wid, void* data) {
    UIGroupManager* manager = reinterpret_cast<UIGroupManager*>(data);
    manager->switch_group("menu");
}

FractalGroup::FractalGroup (int w, int h, UIGroupManager* manager, int x,
                            int y)
    : UIGroup(w, h, manager, x, y) {
    {
        to_menu_btn = new Fl_Button{200, 200, 80, 20, "To Menu"};
        to_menu_btn->callback(FractalGroup::to_menu_btn_callback,
                              &manager_);
    }
    this->end();
}