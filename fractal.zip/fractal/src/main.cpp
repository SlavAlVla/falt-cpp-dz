#include "gui/MainWindow/MainWindow.h"
#include <FL/Fl.H>

int main (int argc, char* argv[]) {
    MainWindow* win = new MainWindow{};

    return Fl::run();
}